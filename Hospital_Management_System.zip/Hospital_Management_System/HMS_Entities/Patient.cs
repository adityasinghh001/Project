﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMS_Entities
{
    public class Patient
    {
        public int PatId { get; set; }
        public string PatName { get; set; }
        public int Age { get; set; }
        public int Weight { get; set; }
        public string Gender { get; set; }
        public string Address { get; set; }
        public int PhoneNumber { get; set; }
        public string Disease{ get; set; }
        public int DoctorID { get; set; }
        public string DoctorName { get; set; }
        public string Department { get; set; }
        public int LabID { get; set; }
        public string TestType { get; set; }
        public DateTime TestDate { get; set; }
        public string PatientType { get; set; }
        public int RoomNo { get; set; }
        public DateTime RTreatmentDate { get; set; }
        public DateTime OTreatmentDate { get; set; }
        public DateTime AdmissionDate { get; set; }
        public DateTime DischargeDate { get; set; }
        public int AmountPerDay { get; set; }
        public int BillNo { get; set; }
     //   public int PatientType { get; set; }
        public int DoctorFees { get; set; }
        public int RoomCharge { get; set; }
        public int OperationCharges { get; set; }
        public int MedicineFees { get; set; }
        public int TotalDays { get; set; }
        public int LabFees { get; set; }
        public int Amount { get; set; }
    }
}
