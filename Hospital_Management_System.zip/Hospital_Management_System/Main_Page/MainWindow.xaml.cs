﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Main_Page
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnPatient_Click(object sender, RoutedEventArgs e)
        {
          //  var page2 = new PatientPage();
          ////  NavigationService.Navigate(page2);
          //  this.Frame.Navigate(typeof(PatientPage);
          //  //PatientPage patientPage = new PatientPage(); 
          //  //this.Content = patientPage;
          //  Frame.Navigate(typeof(PatientPage));
        }

        private void BtnDoctor_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnLab_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnExpenses_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnGenerateBill_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
