export class Room {
     RoomId :number;
    RoomType :string;
     CheckIn :Date;
     CheckOut :Date;
    Capacity :number;
    Tarrif:number;
    HotelId:number;
    HotelName:string;
}
