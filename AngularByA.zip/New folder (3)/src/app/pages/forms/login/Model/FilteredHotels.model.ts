export class FilteredHotels{

    HotelId:number;
  
    HotelName:string;
  
    HotelCity:string;
  
    TotalRooms:number;
  
    BookedRooms:number;
  
    MinTarrif:number;
  
  
  
  }