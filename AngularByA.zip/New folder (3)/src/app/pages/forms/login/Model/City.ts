export class City {
    CityName : string;
    CityId : number;
}