export class homepage {
   
    HotelCity : string;

    CheckIn:Date;

    CheckOut:Date;

}