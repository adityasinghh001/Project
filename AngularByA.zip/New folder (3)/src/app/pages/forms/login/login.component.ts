import { Component, OnInit } from '@angular/core';

import { FormBuilder, Validators, FormGroup, FormControl } from '@angular/forms';


import { Observable } from 'rxjs';
import { City } from './Model/City';

import { Hotel } from '../Hotel/hotel';
import { LoginService } from './LoginService.service';
import { FilteredHotels } from './Model/FilteredHotels.model';
import { homepage } from './Model/homepage.model';
import { HotelService } from '../hotel.service';
import { DatePipe } from '@angular/common';









@Component({

  selector: 'app-homePage',

  templateUrl: '../login/login.component.html',

  //styleUrls: ['./employee.component.css']

 })



export class HomepageComponent implements OnInit {



  homepageForm: any;

  dataSaved = false; 

  private allCity : Observable<City[]>;
//   private allHotels : Observable<Hotel[]>;
private allHotels : FilteredHotels[];

  private hotelavailable : Observable<Hotel[]>;

  private FilteredHotelsList:Observable<FilteredHotels[]>;





  constructor(private formbulider: FormBuilder, private loginService:LoginService,private hotelService:HotelService,public datepipe: DatePipe) { }



  ngOnInit() {

    this.homepageForm=this.formbulider.group({



      HotelCity : ['', [Validators.required]],

      CheckIn:['', [Validators.required]],

      CheckOut:['', [Validators.required]],





    })



    this.fillCity();
    //this.allHotels=this.hotelService.getAllHotel();

   }





  fillCity(){

    //debugger;

    // this.SelState = event.target.value;

    this.allCity = this.loginService.CityData()



  }

  City:string;

  CIDate:Date;
  CI_Date:string;
  CO_Date:string;

  CODate:Date;
  
//   onFormSubmit() {  
     
   
//     // this.City= this.homepageForm.controls['Hotelcity'].getValue();
//     // this.CIDate= this.homepageForm.controls['CheckIn'].getValue();
//     // this.CODate= this.homepageForm.controls['CheckOut'].getValue();
//     this.Search(details);
     
//   } 

home:homepage;
hotel : any;
  Search(){
      
    const details = this.homepageForm.value; 
    this.home=details; 
    this.City=this.home.HotelCity;
    this.CIDate=this.home.CheckIn;
    this.CODate=this.home.CheckOut;

    this.CI_Date=this.datepipe.transform(this.CIDate, 'yyyy-MM-dd');
    this.CO_Date=this.datepipe.transform(this.CODate, 'yyyy-MM-dd');


    console.log("City=",this.City);
    console.log("CI=",this.CI_Date);
    console.log("CO=",this.CODate);
    
 this.loginService.FilteredHotelService(this.City,this.CI_Date,this.CO_Date).subscribe(  
        (allHotels => {  
         this.dataSaved=true;
         this.hotel=allHotels;
          
        
        } ) );
        console.log("CO=",this.hotel);
        this.allHotels=this.hotel;
    // this.allHotels=this.hotel;
    this.homepageForm.reset(); 

  }





}



