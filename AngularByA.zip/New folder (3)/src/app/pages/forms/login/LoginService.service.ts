import { Injectable } from '@angular/core';  
import { HttpClient } from '@angular/common/http';  
import { HttpHeaders } from '@angular/common/http';  
import { Observable } from 'rxjs';  

import { City } from './Model/City';
import { FilteredHotels } from './Model/FilteredHotels.model';
//import { Hotel } from '../pages/forms';


 @Injectable({  
  providedIn: 'root'  
})  
  
export class LoginService {  
  url = 'http://localhost:61672/Api/HMS/';  
  constructor(private http: HttpClient) { }  

CityData(): Observable<City[]>  

{  

 return this.http.get<City[]>(this.url + '/LocationCity');  

}  



FilteredHotelService(city:string, CheckInDate:string ,CheckOutDate:string ): Observable<FilteredHotels[]>  

{  
   
 //return this.http.get<FilteredHotels[]>(this.url + '/GetHotels');  

 //const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json'}) };  

 // return this.http.post<FilteredHotels[]>(this.url+'/GetHotels?city='+city+'&CheckIn='+CheckInDate+'&CheckOut='+CheckOutDate,httpOptions); 


 return this.http.get<FilteredHotels[]>(this.url+'GetHotels?city='+city+'&CheckIn='+CheckInDate+'&CheckOut='+CheckOutDate); 
//return this.http.get<FilteredHotels[]>(this.url+ 'GetHotels?city=Pune&CheckIn=2019-05-13&CheckOut=2019-05-19'); 



 // return this.http.post<FilteredHotels[]>(this.url+'/GetHotels/',city,CheckInDate,CheckOutDate); 

 

} 
}