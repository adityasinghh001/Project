import { Component } from '@angular/core';

@Component({
    selector:"customer-form",
    templateUrl:'customer.component.html'
})

export class CustomerComponent{
    title = 'Customer Registration';
}