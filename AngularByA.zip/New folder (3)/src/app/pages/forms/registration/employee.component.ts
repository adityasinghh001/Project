import { Component } from '@angular/core';

@Component({
    selector:"employee-form",
    templateUrl:'employee.component.html'
})

export class EmployeeComponent{
    title = 'Employee Registration';
}