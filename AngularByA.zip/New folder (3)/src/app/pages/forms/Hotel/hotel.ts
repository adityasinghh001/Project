export class Hotel {

     HotelId:number ;
     HotelName :string;
    HotelCity:string;
   TotalRooms :Number;
   BookedRooms : Number;
   MinTarrif : number;
   Offers:number;
}
 