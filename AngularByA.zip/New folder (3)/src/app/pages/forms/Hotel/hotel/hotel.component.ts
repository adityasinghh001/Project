/*import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hotel',
  templateUrl: './hotel.component.html',
  styleUrls: ['./hotel.component.css']
})
export class HotelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
*/
import { Component, OnInit } from '@angular/core';  
import { FormBuilder, Validators } from '@angular/forms';  
import { Observable } from 'rxjs';  
 

import { Hotel } from '../hotel';
//import { HotelService } from '../../../../HotelServices/Hotel.Service';
import { HotelService } from '../../hotel.service';
  
@Component({  
  selector: 'app-hotel',  
  templateUrl: './hotel.component.html',  
  styleUrls: ['./hotel.component.css']  
})  
export class HotelComponent implements OnInit {  
  dataSaved = false;  
  hotelForm: any;  
  allHotels: Observable<Hotel[]>;  
  hotelIdUpdate = null;  
  massage = null;  
  
 //constructor(private formbulider: FormBuilder, private hotelService:HotelService) { }  
 constructor(private formbulider:FormBuilder,private hotelService:HotelService)
{}  
  ngOnInit() {  
    this.hotelForm = this.formbulider.group({  
      HotelName: ['', [Validators.required]],  
      HotelCity: ['', [Validators.required]],  
      TotalRooms: ['', [Validators.required]], 
      
      MinTarrif :  ['', [Validators.required]] ,
      Offers :  ['', [Validators.required]] 

     
    });  
    this.loadAllHotel();  
  }  
  loadAllHotel()
   {  
    this.allHotels = this.hotelService.getAllHotel();  
  }  
  onFormSubmit() {  
    this.dataSaved = false;  
    const hotel = this.hotelForm.value;  
    this.Createhotel(hotel);  
    this.hotelForm.reset();  
  }  
  loadHotelToEdit(hotelId: number) {  

    this.hotelService.getHotelById(hotelId).subscribe(hotel=> {  
      this.massage = null;  
      this.dataSaved = false;  
      this.hotelIdUpdate = hotel.HotelId;  
      this.hotelForm.controls['HotelName'].setValue(hotel.HotelName);  
     this.hotelForm.controls['HotelCity'].setValue(hotel.HotelCity); 
     this.hotelForm.controls['TotalRooms'].setValue(hotel.TotalRooms);  
     this.hotelForm.controls['MinTarrif'].setValue(hotel.MinTarrif);  
     this.hotelForm.controls['Offers'].setValue(hotel.Offers);  
      
    });  
  
  }  
  Createhotel(hotel: Hotel) {  
    if (this.hotelIdUpdate == null) {  
      this.hotelService.createHotel(hotel).subscribe(  
        () => {  
          this.dataSaved = true;  
          this.massage = 'Record saved Successfully';  
          this.loadAllHotel();  
          this.hotelIdUpdate = null;  
          this.hotelForm.reset();  
        }  
      );  
    } else {  
      hotel.HotelId = this.hotelIdUpdate;  
      this.hotelService.updateHotel(hotel).subscribe(() => {  
        this.dataSaved = true;  
        this.massage = 'Record Updated Successfully';  
        this.loadAllHotel();  
        this.hotelIdUpdate = null;  
        this.hotelForm.reset();  
      });  
    }  
  }   
  deletehotel(hotelId: number) {  
    if (confirm("Are you sure you want to delete this ?")) {   
    this.hotelService.deleteHotelById(hotelId).subscribe(() => {  
      this.dataSaved = true;  
      this.massage = 'Record Deleted Succefully';  
      this.loadAllHotel();  
      this.hotelIdUpdate = null;  
      this.hotelForm.reset();  
  
    });  
  }  
}  
  resetForm() {  
    this.hotelForm.reset();  
    this.massage = null;  
    this.dataSaved = false;  
  }  
} 
