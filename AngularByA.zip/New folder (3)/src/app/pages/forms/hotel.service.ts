import { Injectable } from '@angular/core';  
import { HttpClient } from '@angular/common/http';  
import { HttpHeaders } from '@angular/common/http';  
import { Observable } from 'rxjs';  
import { Hotel } from './Hotel/hotel';
//import { Hotel } from '../pages/forms';


 @Injectable({  
  providedIn: 'root'  
})  
  
export class HotelService {  
  url = 'http://localhost:61672/Api/HMS/';  
  constructor(private http: HttpClient) { }  

  getAllHotel(): Observable<Hotel[]> {  
    return this.http.get<Hotel[]>(this.url + '/AllHotelDetails');  
  }  
  getHotelById(hotelId: number): Observable<Hotel> {  
    return this.http.get<Hotel>(this.url + '/GetHotelDetailsById/' + hotelId);  
  }  
  createHotel(hotel: Hotel): Observable<Hotel> {  
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json'}) };  
    return this.http.post<Hotel>(this.url + '/InsertHotelDetails/',  
    hotel, httpOptions);  
  }  
  updateHotel(hotel: Hotel): Observable<Hotel> {  
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json'}) };  
    return this.http.put<Hotel>(this.url + '/UpdateHotelDetails/',  
    hotel, httpOptions);  
  }  
  deleteHotelById(hotelId: number): Observable<number> {  
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json'}) };  
    return this.http.delete<number>(this.url + '/DeleteHotelDetails?id=' +hotelId,  
 httpOptions);  
  }  
}  