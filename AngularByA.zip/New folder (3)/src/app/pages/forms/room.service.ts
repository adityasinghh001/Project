import { Injectable } from '@angular/core';  
import { HttpClient } from '@angular/common/http';  
import { HttpHeaders } from '@angular/common/http';  
import { Observable } from 'rxjs';  

import { Room } from './room';
//import { Room } from '../pages/forms';


 @Injectable({  
  providedIn: 'root'  
})  
  
export class RoomService {  
  url = 'http://localhost:61672/Api/HMS';  
  constructor(private http: HttpClient) { }  

  //getAllRoom(): Observable<Room[]> 
  getAllRoom():Observable<Room[]>
  {  
    return this.http.get<Room[]>(this.url + '/AllRoomDetails');  
  }  
  getRoomById(RoomId: number): Observable<Room> {  
    return this.http.get<Room>(this.url + '/GetRoomDetailsById/' + RoomId);  
  }  
  createRoom(Room: Room): Observable<Room> {  
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json'}) };  
    return this.http.post<Room>(this.url + '/InsertRoomDetails/',  
    Room, httpOptions);  
  }  
  updateRoom(Room: Room): Observable<Room> {  
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json'}) };  
    return this.http.put<Room>(this.url + '/UpdateRoomDetails/',  
    Room, httpOptions);  
  }  
  deleteRoomById(RoomId: number): Observable<number> {  
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json'}) };  
    return this.http.delete<number>(this.url + '/DeleteRoomDetails?id=' +RoomId,  
 httpOptions);  
  }  
}  