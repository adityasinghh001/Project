/*import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-Room',
  templateUrl: './Room.component.html',
  styleUrls: ['./Room.component.css']
})
export class RoomComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
*/
import { Component, OnInit } from '@angular/core';  
import { FormBuilder, Validators } from '@angular/forms';  
import { Observable } from 'rxjs';  
 

import { Room } from '../Room';
//import { RoomService } from '../../../../RoomServices/Room.Service';

import { RoomService } from '../room.service';
import { Hotel } from '../Hotel/hotel';
import { HotelService } from '../hotel.service';
  
@Component({  
  selector: 'app-Room',  
  templateUrl: './Room.component.html',  
  styleUrls: ['./Room.component.css']  
})  
export class RoomComponent implements OnInit {  
  dataSaved = false;  
  RoomForm: any;
  allHotels: Observable<Hotel[]>;  
  allRooms: Observable<Room[]>;  
  RoomIdUpdate = null;  
  massage = null;  
  

// constructor(private formbulider:FormBuilder,private RoomService:RoomService)
constructor(private formbulider:FormBuilder,private RoomService:RoomService,private HotelService:HotelService)
{}  
  ngOnInit() {  
    this.RoomForm = this.formbulider.group({ 
      HotelName: ['', [Validators.required]],
      RoomType: ['', [Validators.required]],  
      Capacity: ['', [Validators.required]],  
      Tarrif: ['', [Validators.required]],  
     
    });  
    this.loadAllRoom();  
    this.loadAllHotels();
  }  
  loadAllRoom()
   {  
    this.allRooms = this.RoomService.getAllRoom();  
  }  
  loadAllHotels()
  {  
   this.allHotels = this.HotelService.getAllHotel();  
 }
  onFormSubmit() {  
    this.dataSaved = false;  
    const Room = this.RoomForm.value;  
    this.CreateRoom(Room);  
    this.RoomForm.reset();  
  }  
  loadRoomToEdit(RoomId: number) {  

    this.RoomService.getRoomById(RoomId).subscribe(Room=> {  
      this.massage = null;  
      this.dataSaved = false;  
      this.RoomIdUpdate = Room.RoomId;
      this.RoomForm.controls['HotelName'].setValue(Room.HotelName);    
      this.RoomForm.controls['RoomType'].setValue(Room.RoomType);  
     this.RoomForm.controls['Capacity'].setValue(Room.Capacity); 
     this.RoomForm.controls['Tarrif'].setValue(Room.Tarrif);  
      
    });  
  
  }  
  CreateRoom(Room: Room) {  
    if (this.RoomIdUpdate == null) {  
      this.RoomService.createRoom(Room).subscribe(  
        () => {  
          this.dataSaved = true;  
          this.massage = 'Record saved Successfully';  
          this.loadAllRoom();  
          this.RoomIdUpdate = null;  
          this.RoomForm.reset();  
        }  
      );  
    } else {  
      Room.RoomId = this.RoomIdUpdate;  
      this.RoomService.updateRoom(Room).subscribe(() => {  
        this.dataSaved = true;  
        this.massage = 'Record Updated Successfully';  
        this.loadAllRoom();  
        this.RoomIdUpdate = null;  
        this.RoomForm.reset();  
      });  
    }  
  }   
  deleteRoom(RoomId: number) {  
    if (confirm("Are you sure you want to delete this ?")) {   
    this.RoomService.deleteRoomById(RoomId).subscribe(() => {  
      this.dataSaved = true;  
      this.massage = 'Record Deleted Succefully';  
      this.loadAllRoom();  
      this.RoomIdUpdate = null;  
      this.RoomForm.reset();  
  
    });  
  }  
}  
  resetForm() {  
    this.RoomForm.reset();  
    this.massage = null;  
    this.dataSaved = false;  
  }  
} 
