import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { CustomerComponent } from './pages/forms/registration/customer.component';
import { EmployeeComponent } from './pages/forms/registration/employee.component';
import { HotelComponent } from './pages/forms/Hotel/hotel/hotel.component';
import {  
  MatButtonModule, MatMenuModule, MatDatepickerModule,MatNativeDateModule , MatIconModule, MatCardModule, MatSidenavModule,MatFormFieldModule,  
  MatInputModule, MatTooltipModule, MatToolbarModule, MatSelectChange  
} from '@angular/material';  
import { MatRadioModule } from '@angular/material/radio';  
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'; 
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { RoomComponent } from './pages/forms/room/room.component';
import { AdminComponent } from './pages/forms/AdminHome/admin/admin.component';
import { HomepageComponent } from './pages/forms/login/login.component';
import { DatePipe } from '@angular/common';


@NgModule({
  declarations: [
    AppComponent,HomepageComponent, CustomerComponent, EmployeeComponent, HotelComponent, RoomComponent, AdminComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,  
    HttpClientModule,
    MatButtonModule,  
    MatMenuModule,  
    MatDatepickerModule,  
    MatNativeDateModule,  
    MatIconModule,  
    MatRadioModule,  
    MatCardModule,  
    MatSidenavModule,  
    MatFormFieldModule,  
    MatInputModule,  
    MatTooltipModule,  
    MatToolbarModule,  
    AppRoutingModule  ,
    ReactiveFormsModule,
    FormsModule,
     MatFormFieldModule,
    MatInputModule,
    MatInputModule
   
  ],
  providers: [DatePipe],
  bootstrap: [AppComponent]
})
export class AppModule { }
