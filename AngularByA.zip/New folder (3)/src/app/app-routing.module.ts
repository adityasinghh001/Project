import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployeeComponent } from './pages/forms/registration/employee.component';
import { CustomerComponent } from './pages/forms/registration/customer.component';
import { HotelComponent } from './pages/forms/Hotel/hotel/hotel.component';
import { RoomComponent } from './pages/forms/room/room.component';
import { AdminComponent } from './pages/forms/AdminHome/admin/admin.component';
import { HomepageComponent } from './pages/forms/login/login.component';


const routes: Routes = [
  {path:'homepage',component:HomepageComponent},
  {path:'employee',component:EmployeeComponent},
  {path:'customer',component:CustomerComponent},
  {path:'hotel',component:HotelComponent},
  {path:'room',component:RoomComponent},
  {path:'home',component:AdminComponent},
  {path:'',component:AdminComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
